#include "BuddyAllocator.h"
#include <iostream>
#include <cmath>
#include <cstdint>
using namespace std;

BuddyAllocator::BuddyAllocator(int _basic_block_size, int _total_memory_length)
{
  basic_block_size = _basic_block_size;
  total_memory_size = _total_memory_length;

  //Create the total memory block
  start = new char[total_memory_size];
  //Function to find j; Last index for the FREELIST
  int j = ceil(log2(total_memory_size / basic_block_size));
  //Create Empty Linked Lists on the Free List Vector
  for (int i = 0; i <= j; i++)
  {
    FreeList.push_back(LinkedList());
  }
  //Set Block Header at the front of the total memory holding all block info
  BlockHeader *b = (BlockHeader *)start;
  b->block_size = total_memory_size, b->next = nullptr, b->free = true;
  //Insert block header at last index of free list
  FreeList[j].insert(b);
}

BuddyAllocator::~BuddyAllocator()
{
  delete start; // delete the starting memory
}

BlockHeader *BuddyAllocator::getbuddy(BlockHeader *addr)
{
  int blockSize = addr->block_size;
  int offset = ((char *)(addr)-start);
  //Returns the buddy address of the given block header
  return (BlockHeader *)((offset ^ addr->block_size) + start);
}

BlockHeader *BuddyAllocator::merge(BlockHeader *block1, BlockHeader *block2)
{
  //compares which block comes first
  if (block1 > block2)
  {
    block2->block_size = block2->block_size * 2;
    return block2;
  }
  else
  {
    block1->block_size = block1->block_size * 2;
    return block1;
  }
}

BlockHeader *BuddyAllocator::split(BlockHeader *block)
{
  //Set a pointer at the half of the block given
  BlockHeader *half = (BlockHeader *)((char *)block + (block->block_size / 2));
  //Update block size for split blocks to half of the original
  half->block_size = block->block_size / 2;
  block->block_size = block->block_size / 2;
  //Update rest of block header info for the new split block
  half->free = true, half->next = nullptr;
  return half;
}

char *BuddyAllocator::alloc(int _length)
{
  /* This preliminary implementation simply hands the call over the 
     the C standard library! 
     Of course this needs to be replaced by your implementation.
  */
  //Update length adding size of block header
  int length = _length + sizeof(BlockHeader);
  //If requested length is longer than the total memory size, return null
  if (length > total_memory_size)
  {
    cout << "Request is exceeds max block size." << endl;
    return nullptr;
  }
  //Find index of the minimum block needed
  float num = ceil((double)length / basic_block_size);
  num = ceil(num);
  int i = ceil(log2(num));
  BlockHeader *cur = FreeList[i].head;
  //If element exists in that ith index of the free list
  if (FreeList[i].head)
  {
    if (FreeList[i].head->free == true)
    { //If first element in linked list is available
      BlockHeader *b = FreeList[i].head;
      FreeList[i].remove(FreeList[i].head);
      b->free = false;
      return (char *)(b + 1);
    }
    else
    { //If first element in linked list is not available, find next available block
      while (cur->free == false)
      {
        cur = cur->next;
      }
      //Once found, remove from free list
      BlockHeader *b = cur;
      FreeList[i].remove(cur);
      b->free = false;
      return (char *)(b + 1);
    }
  }
  else
  { // ith block is empty
    int j = i;
    while (FreeList[j].head == NULL)
    {
      j++; //will keep going through the free list if nothing is found so compare with last index
      if (j == FreeList.size())
      { //once j is the length of the free list, reached end of list
        return NULL;
      }
    }
    //Start splitting through the blocks
    while (j > i)
    {
      BlockHeader *b = FreeList[j].head;
      FreeList[j].remove(FreeList[j].head);
      BlockHeader *bb = split(b);
      FreeList[j - 1].insert(bb); //insert the split blocks to lower index of free list
      FreeList[j - 1].insert(b);
      j--; // decrease to keep splitting blocks
    }
  }
  FreeList[i].head->free = false; //Set the block as filled up; not free to use
  BlockHeader *open = FreeList[i].head;
  FreeList[i].remove(FreeList[i].head); //remove from free list
  return (char *)(open + 1);
}

int BuddyAllocator::free(char *_a)
{
  /* Same here! */
  BlockHeader *b = (BlockHeader *)(_a - sizeof(BlockHeader));
  //BlockHeader* m = b;

  //Starts at the lowest index available to free
  while (true)
  {
    int i = (log2(ceil((double)b->block_size / basic_block_size)));
    if (i == FreeList.size())
    {
      break; //i has reached the end of the free list
    }
    BlockHeader *bb = getbuddy(b);
    if (bb->free == false)
    {
      FreeList[i].insert(b); //if buddy is not free, insert the block back into the free list for later use
      b->free = true;
      return 0;
    }
    else
    {
      BlockHeader *temp = bb;
      FreeList[i].remove(bb); //remove buddy block from free list
      b = merge(b, temp);     //merge buddy block and from original block
      b->free = true;         // block is free for later use
    }
  }
  //Find lowest index where merged block should be
  int i = (log2(ceil((double)b->block_size / basic_block_size)));
  FreeList[i + 1].insert(b); // insert the merged block back to free list
  b->free = true;            // block is free to use later
  return 0;
}

void BuddyAllocator::printlist()
{
  cout << "Printing the Freelist in the format \"[index] (block size) : # of blocks\"" << endl;
  for (int i = 0; i < FreeList.size(); i++)
  {
    cout << "[" << i << "] (" << ((1 << i) * basic_block_size) << ") : "; // block size at index should always be 2^i * bbs
    int count = 0;
    BlockHeader *b = FreeList[i].head;
    // go through the list from head to tail and count
    while (b)
    {
      count++;
      // block size at index should always be 2^i * bbs
      // checking to make sure that the block is not out of place
      if (b->block_size != (1 << i) * basic_block_size)
      {
        cerr << "ERROR:: Block is in a wrong list" << endl;
        exit(-1);
      }
      b = b->next;
    }
    cout << count << endl;
  }
}
